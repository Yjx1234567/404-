function checkAuth() {
    const user = localStorage.getItem('user');
    if (!user) {
        const publicPages = ['/login.html', '/register.html', '/index.html', '/'];
        const current = window.location.pathname;
        if (!publicPages.some(p => current.endsWith(p))) {
            window.location.href = 'login.html';
        }
        return null;
    }
    return JSON.parse(user);
}

function updateUserInfo() {
    const userInfo = document.getElementById('userInfo');
    if (!userInfo) return;
    const user = checkAuth();
    if (user) {
        let html = user.username;
        if (user.role === 'admin') {
            html += ' <span class="admin-badge">管理员</span>';
        }
        userInfo.innerHTML = html;
        
        const adminLink = document.getElementById('adminLink');
        if (adminLink) {
            adminLink.classList.toggle('hidden', user.role !== 'admin');
        }
    }
}

function logout() {
    localStorage.removeItem('user');
    logoutUser().then(() => {
        window.location.href = 'login.html';
    });
}

// Login form
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errorDiv = document.getElementById('loginError');
        errorDiv.textContent = '';
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        
        const { status, data } = await loginUser(username, password);
        if (status === 200 && data.message === 'login successful') {
            localStorage.setItem('user', JSON.stringify({
                username: data.username,
                role: data.role
            }));
            window.location.href = 'problem_list.html';
        } else {
            errorDiv.textContent = data.error || '登录失败';
        }
    });
}

// Register form
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errorDiv = document.getElementById('registerError');
        errorDiv.textContent = '';
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        if (password !== confirmPassword) {
            errorDiv.textContent = '两次输入的密码不一致';
            return;
        }
        
        const { status, data } = await registerUser(username, password);
        if (status === 201 || data.message === 'user registered successfully') {
            alert('注册成功，请登录');
            window.location.href = 'login.html';
        } else {
            errorDiv.textContent = data.error || '注册失败';
        }
    });
}

// Logout button
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
}

// Redirect logged-in users from login/register to problem list
const user = checkAuth();
if (user) {
    const current = window.location.pathname;
    if (current.endsWith('/login.html') || current.endsWith('/register.html')) {
        window.location.href = 'problem_list.html';
    }
}

updateUserInfo();
