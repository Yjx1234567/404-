// 题目列表：服务端分页 + 难度筛选 + 标题关键词搜索
// （题量大时不再一次拉全量，翻页/筛选都走 GET /api/problems 查询参数）

const PAGE_SIZE = 20;

let state = {
    page: 1,
    difficulty: 'all',
    keyword: '',
    total: 0
};

let searchTimer = null;

async function loadProblems() {
    const list = document.getElementById('problemList');
    list.innerHTML = '<div class="loading">加载中...</div>';

    const params = { page: state.page, page_size: PAGE_SIZE };
    if (state.difficulty !== 'all') params.difficulty = state.difficulty;
    if (state.keyword) params.keyword = state.keyword;

    const { status, data } = await getProblems(params);
    if (status !== 200 || !data.problems) {
        list.innerHTML = '<div class="empty-state">加载失败</div>';
        return;
    }

    state.total = data.total;
    renderProblems(data.problems);
    renderPagination();
}

function renderProblems(problems) {
    const list = document.getElementById('problemList');

    if (problems.length === 0) {
        list.innerHTML = '<div class="empty-state">暂无题目</div>';
        return;
    }

    list.innerHTML = problems.map(p => `
        <a href="problem.html?id=${p.id}" class="problem-card">
            <div class="problem-card-header">
                <span class="problem-card-title">#${p.id} ${p.title}</span>
                <span class="difficulty-tag ${p.difficulty.toLowerCase()}">${p.difficulty}</span>
            </div>
            <div class="problem-card-meta">创建时间: ${p.created_at}</div>
        </a>
    `).join('');
}

function renderPagination() {
    const el = document.getElementById('pagination');
    const totalPages = Math.max(1, Math.ceil(state.total / PAGE_SIZE));
    if (totalPages <= 1) {
        el.innerHTML = '';
        return;
    }
    el.innerHTML = `
        <button class="page-btn" id="prevPage" ${state.page <= 1 ? 'disabled' : ''}>&laquo; 上一页</button>
        <span class="page-info">第 ${state.page} / ${totalPages} 页（共 ${state.total} 题）</span>
        <button class="page-btn" id="nextPage" ${state.page >= totalPages ? 'disabled' : ''}>下一页 &raquo;</button>
    `;
    document.getElementById('prevPage').addEventListener('click', () => {
        if (state.page > 1) { state.page--; loadProblems(); }
    });
    document.getElementById('nextPage').addEventListener('click', () => {
        if (state.page < totalPages) { state.page++; loadProblems(); }
    });
}

// 难度筛选按钮：切换后从第一页重新查询
const filterButtons = document.querySelectorAll('.filter-btn');
filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        filterButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.difficulty = btn.dataset.filter;
        state.page = 1;
        loadProblems();
    });
});

// 标题搜索：输入防抖 400ms 后自动查询，回车立即查
const searchInput = document.getElementById('searchInput');
searchInput.addEventListener('input', () => {
    if (searchTimer) clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
        state.keyword = searchInput.value.trim();
        state.page = 1;
        loadProblems();
    }, 400);
});
searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        if (searchTimer) clearTimeout(searchTimer);
        state.keyword = searchInput.value.trim();
        state.page = 1;
        loadProblems();
    }
});

loadProblems();
