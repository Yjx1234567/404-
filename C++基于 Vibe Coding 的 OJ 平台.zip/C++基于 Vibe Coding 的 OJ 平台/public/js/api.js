const BASE_URL = '/api';

async function request(url, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        },
        credentials: 'same-origin'
    };
    const response = await fetch(url, { ...defaultOptions, ...options });
    const data = await response.json().catch(() => ({}));
    return { status: response.status, data };
}

// 把 {key: value} 对象拼成查询串（跳过空值）
function buildQuery(params = {}) {
    const pairs = Object.entries(params)
        .filter(([, v]) => v !== undefined && v !== null && v !== '')
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`);
    return pairs.length ? `?${pairs.join('&')}` : '';
}

async function getProblems(params = {}) {
    return request(`${BASE_URL}/problems${buildQuery(params)}`);
}

async function getProblem(id) {
    return request(`${BASE_URL}/problems/${id}`);
}

async function getTags() {
    return request(`${BASE_URL}/tags`);
}

async function submitCode(code, problemId) {
    return request(`${BASE_URL}/submit`, {
        method: 'POST',
        body: JSON.stringify({ code, problem_id: problemId })
    });
}

// 提交详情（含判题结果）；轮询时反复调用直到状态离开 PENDING/JUDGING
async function getSubmission(id) {
    return request(`${BASE_URL}/submissions/${id}`);
}

// 我的提交历史；参数：{problem_id, page, page_size, user_id(admin)}
async function getSubmissions(params = {}) {
    return request(`${BASE_URL}/submissions${buildQuery(params)}`);
}

async function getMyStats() {
    return request(`${BASE_URL}/users/me/stats`);
}

async function getLeaderboard() {
    return request(`${BASE_URL}/leaderboard`);
}

async function registerUser(username, password) {
    return request(`${BASE_URL}/register`, {
        method: 'POST',
        body: JSON.stringify({ username, password })
    });
}

async function loginUser(username, password) {
    return request(`${BASE_URL}/login`, {
        method: 'POST',
        body: JSON.stringify({ username, password })
    });
}

async function logoutUser() {
    return request(`${BASE_URL}/logout`, { method: 'POST' });
}

async function createProblem(problem) {
    return request(`${BASE_URL}/admin/problems`, {
        method: 'POST',
        body: JSON.stringify(problem)
    });
}

async function getProblemAdmin(id) {
    return request(`${BASE_URL}/admin/problems/${id}`);
}

async function updateProblem(id, problem) {
    return request(`${BASE_URL}/admin/problems/${id}`, {
        method: 'PUT',
        body: JSON.stringify(problem)
    });
}

async function deleteProblem(id) {
    return request(`${BASE_URL}/admin/problems/${id}`, {
        method: 'DELETE'
    });
}
