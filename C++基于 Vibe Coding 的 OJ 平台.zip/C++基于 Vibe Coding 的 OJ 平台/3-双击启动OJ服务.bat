@echo off
chcp 65001 >nul
title Step 3 - Start OJ server

echo.
echo  ============================================
echo   STEP 3 / 3 :  Start MySQL + OJ server
echo.
echo   - Asks your WSL password once (INVISIBLE
echo     while typing, just type and press Enter)
echo   - Wait until you see :
echo     Server starting on 0.0.0.0:8080
echo   - Then open browser : http://localhost:8080
echo   - Keep this window OPEN while using the OJ
echo   - To stop the server : press Ctrl + C
echo.
echo   NOTE : if this is your FIRST time, run
echo   2-  (deploy) instead of this file.
echo  ============================================
echo.

wsl -d Ubuntu-22.04 -- bash -c "sudo service mysql start; cd ~/oj_platform 2>/dev/null || { echo '[ERROR] ~/oj_platform not found.'; echo '[ERROR] Please run the file starting with  2-  FIRST.'; exit 1; }; ./build/oj_server"

pause
