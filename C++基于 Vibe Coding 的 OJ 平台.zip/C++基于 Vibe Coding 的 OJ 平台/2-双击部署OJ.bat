@echo off
chcp 65001 >nul
title Step 2 - Deploy OJ platform in WSL

echo.
echo  ============================================
echo   STEP 2 / 3 :  Deploy the OJ platform
echo.
echo   - Runs inside WSL(Ubuntu-22.04)
echo   - About 5-15 min (first time is slow)
echo   - It will ask your WSL password once :
echo     the password is INVISIBLE while typing
echo   - Question [Y/n] : just press Enter
echo   - Do NOT close this window
echo  ============================================
echo.

wsl -d Ubuntu-22.04 -- bash -c "cd /mnt/d/Lfp/Desktop/C++*OJ* && pwd && chmod +x fix_sources.sh setup.sh && bash fix_sources.sh && ./setup.sh"

echo.
echo  ============================================
echo   Deployment step finished.
echo.
echo   SUCCESS looks like :
echo     Server starting on 0.0.0.0:8080
echo.
echo   Then open your browser at :
echo     http://localhost:8080
echo.
echo   If you see any red ERROR above :
echo   take a screenshot and send it to the
echo   AI assistant.
echo  ============================================
pause
