#!/usr/bin/env bash
# ============================================================================
# 存量数据库迁移脚本（幂等，可重复运行）
# 用途：老版本初始化的数据库缺少新增列/表时，执行本脚本补齐。
#       新装环境直接跑 init.sql 即可，无需本脚本。
# 用法：bash database/migrate.sh   （需能连本机 MySQL 的当前用户）
# ============================================================================
set -e

MYSQL_CMD="mysql -u $(whoami)"

run_alter() {
    # $1: ALTER 语句；列已存在时（MySQL 错误 1060）视为成功跳过
    local stmt="$1"
    local out
    if out=$($MYSQL_CMD oj_system -e "$stmt" 2>&1); then
        echo "  [OK] $stmt"
    elif echo "$out" | grep -q "1060"; then
        echo "  [SKIP] 列已存在: $stmt"
    else
        echo "  [WARN] 执行失败（忽略，不影响新装环境）: $out"
    fi
}

echo "[INFO] 迁移 problems 表：新增 spj_code 列（Special Judge）"
run_alter "ALTER TABLE problems ADD COLUMN spj_code MEDIUMTEXT NULL"

echo "[INFO] 迁移完成"
